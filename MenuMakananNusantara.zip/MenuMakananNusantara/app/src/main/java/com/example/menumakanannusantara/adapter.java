package com.example.menumakanannusantara;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class adapter extends RecyclerView.Adapter<adapter.MyViewHolder> {

    String data1[], data2[];
    int images[];
    Context context;

    public adapter(Context ct, String s1[], String s2[],int img[]){
        context = ct;
        data1 = s1;
        data2 = s2;
        images = img;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.menu.setText(data1[position]);
        holder.deskripsi.setText(data2[position]);
        holder.myimageview.setImageResource(images[position]);
    }

    @Override
    public int getItemCount() {
        return images.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView menu, deskripsi;
        ImageView myimageview;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            menu = itemView.findViewById(R.id.txtmenumakanan);
            deskripsi = itemView.findViewById(R.id.txtdeskripsi);
            myimageview = itemView.findViewById(R.id.myimageview);
        }
    }
}
