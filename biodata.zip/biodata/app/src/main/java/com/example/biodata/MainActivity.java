package com.example.biodata;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void addContact(View v){
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:087731945112"));
        startActivity(intent);
    }

    public void addEmail(View v){
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse("mailto:111201912089@mhs.dinus.ac.id"));
        startActivity(emailIntent);
    }

    public void addLokasi(View v){
        Intent lokasiIntent = new Intent(Intent.ACTION_VIEW);
        lokasiIntent.setData(Uri.parse("geo:-6.989058, 110.400519"));
        lokasiIntent.setPackage("com.google.android.apps.maps");
        startActivity(lokasiIntent);
    }
}