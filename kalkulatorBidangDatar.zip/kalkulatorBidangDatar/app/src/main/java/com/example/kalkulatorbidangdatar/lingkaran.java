package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class lingkaran extends AppCompatActivity {

    Button hitungLuas;
    Button hitungKeliling;
    TextView txtjari;
    TextView txthasil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lingkaran);
        hitungLuas = findViewById(R.id.btnluas);
        hitungKeliling = findViewById(R.id.btnkeliling);
        txtjari = findViewById(R.id.ptjari);
        txthasil = findViewById((R.id.pthasil));
    }
    public void hitungLuas(View v){
        String stringjari = txtjari.getText().toString();
        int intjari = Integer.parseInt(stringjari);

        float hasilLuas =(float) (Math.PI * Math.pow(intjari, 2));

        txthasil.setText(Float.toString(hasilLuas));
    }
    public void hitungKeliling(View v){
        String stringjari = txtjari.getText().toString();
        int intjari = Integer.parseInt(stringjari);

        float hasilKeliling = (float) ((intjari*2)*Math.PI);

        txthasil.setText(Float.toString(hasilKeliling));
    }
}