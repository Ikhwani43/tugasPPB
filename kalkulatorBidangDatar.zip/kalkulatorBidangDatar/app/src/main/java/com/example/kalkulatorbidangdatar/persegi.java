package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class persegi extends AppCompatActivity {

    Button hitungLuas;
    Button hitungKeliling;
    TextView tvpanjang;
    TextView tvlebar;
    TextView tvhasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persegi);
        hitungLuas = findViewById(R.id.luas);
        hitungKeliling = findViewById(R.id.kel);
        tvpanjang = findViewById(R.id.panjang);
        tvlebar = findViewById(R.id.lebar);
        tvhasil = findViewById(R.id.hasil);
    }
    public void hitungLuas(View v){
        String stringPanjang = tvpanjang.getText().toString();
        int intPanjang = Integer.parseInt(stringPanjang);
        String stringLebar = tvlebar.getText().toString();
        int intLebar = Integer.parseInt(stringLebar);

        // operasi kali luas
        int hasilLuas = intPanjang * intLebar;

        tvhasil.setText(Integer.toString(hasilLuas));
    }
    public void hitungKeliling(View v) {
        String stringPanjang = tvpanjang.getText().toString();
        int intPanjang = Integer.parseInt(stringPanjang);
        String stringLebar = tvlebar.getText().toString();
        int intLebar = Integer.parseInt(stringLebar);

        // operasi keliling
        int hasilkeliling = (2 * intPanjang) + (2 * intLebar);

        tvhasil.setText(Integer.toString(hasilkeliling));
    }
}