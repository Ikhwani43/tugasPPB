package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class segitiga extends AppCompatActivity {


    Button hitungLuas;
    Button hitungKeliling;
    TextView txtAlas;
    TextView txtTinggi;
    TextView txtSisi1;
    TextView txtSisi2;
    TextView txthasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segitiga);
        hitungLuas = findViewById(R.id.btnluas);
        hitungKeliling = findViewById(R.id.btnkeliling);
        txtAlas = findViewById(R.id.ptalas);
        txtTinggi = findViewById(R.id.pttinggi);
        txtSisi1 = findViewById(R.id.ptsisi1);
        txtSisi2 = findViewById(R.id.ptsisi2);
        txthasil = findViewById(R.id.pthasil);
    }

    public void hitungLuas(View v){
        String stringAlas = txtAlas.getText().toString();
        int intAlas = Integer.parseInt(stringAlas);
        String stringTinggi = txtTinggi.getText().toString();
        int intTinggi = Integer.parseInt(stringTinggi);

        int hasilLuas = (intAlas * intTinggi) / 2;

        txthasil.setText(Integer.toString(hasilLuas));
    }
    public void hitungKeliling(View v) {
        String stringAlas = txtAlas.getText().toString();
        int intAlas = Integer.parseInt(stringAlas);
        String stringTinggi = txtTinggi.getText().toString();
        int intTinggi = Integer.parseInt(stringTinggi);
        String stringSisi1 = txtSisi1.getText().toString();
        int intSisi1 = Integer.parseInt(stringSisi1);
        String stringSisi2 = txtSisi2.getText().toString();
        int intSisi2 = Integer.parseInt(stringSisi2);

        int hasilKeliling = intAlas + intSisi1 + intSisi2;

        txthasil.setText(Integer.toString(hasilKeliling));
    }
}
